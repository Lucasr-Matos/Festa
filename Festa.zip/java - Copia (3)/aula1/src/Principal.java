public class Principal {
    public static void main(String[] args) {
        Festa festa = new Festa(2);

        for (int i = 0; i < 3; i++) {
            String nome;
         

            double random = Math.random();
            Pessoa pessoa;

            if (random < 0.5) {
                System.out.println("Informe o nome do Homem:");
                 nome = Teclado.leString();
                System.out.println("Informe a idade do homem:");
                int idade = Teclado.leInt();

                System.out.println("Informe a preferência de cabelo do homem:");
                String preferenciaCabelo = Teclado.leString();

                Time time = new Time(Teclado.leString("insira o nome do time"), Teclado.leInt("insira o ano de fundação do time"), Teclado.leInt("Insira a quantidade de sócios do time"));

                pessoa  = new Homem(nome, idade, preferenciaCabelo, time);
            } else {
                System.out.println("Informe o nome da Mulher:");
                 nome = Teclado.leString();

                System.out.println("Informe a idade da mulher:");
                int idade = Teclado.leInt();

                System.out.println("Informe a cor de cabelo da mulher:");
                String corCabelo = Teclado.leString();

                pessoa = new Mulher(nome, idade, corCabelo);
            }

            boolean entrou = festa.entraPessoa(pessoa);

            if (entrou) {
                System.out.println(  nome + " entrou na festa");
            } else {
                System.out.println( nome + " não entrou na festa");
            }
        }
        festa.procuraMulheres();
        festa.imprimeTimeHomens();
        festa.achaParPerfeito();

    }
}
