public class Homem extends Pessoa {
    private Time time;
    private String preferenciaCabelo;

    public Homem(String nome, int idade, String preferenciaCabelo, Time time) {
        super(nome, idade);
        this.preferenciaCabelo = preferenciaCabelo;
        this.time = time;

    }

    public Time getTime() {
        return time;
    }

    public void setTime(Time time) {
        this.time = time;
    }

    public String getPreferenciaCabelo() {
        return preferenciaCabelo;
    }

    public void setPreferenciaCabelo(String preferenciaCabelo) {
        this.preferenciaCabelo = preferenciaCabelo;
    }

    
    @Override
    public String toString() {
        return "Nome: " + getNome() +" , cor de cabelo preferida nas mulheres: " + getPreferenciaCabelo() +
                "\n time do coração : " + getTime();
    }

}
