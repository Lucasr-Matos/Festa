public class Time {
    private String nome;
    private int fundacao;
    private int quantSocios;

    public Time(String nome, int fundacao, int quantSocios) {
        this.nome = nome;
        this.fundacao = fundacao;
        this.quantSocios = quantSocios;

    }

    public String getNome() {
        return nome;
    }

    public int getFundacao() {
        return fundacao;
    }

    public int getQuantSocios() {
        return quantSocios;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setFundacao(int fundacao) {
        this.fundacao = fundacao;
    }

    public void setQuantSocios(int quantSocios) {
        this.quantSocios = quantSocios;
    }

    public String toString() {
        return "Nome do time : " + nome + ", ano de fundação : " + fundacao + ", quantidade de sócios : " + quantSocios;
    }
}
