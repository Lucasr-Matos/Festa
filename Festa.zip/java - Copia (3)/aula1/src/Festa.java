public class Festa {
    private Pessoa[] lista;

    public Festa(int max) {
        lista = new Pessoa[max];

    }

    public Pessoa[] getPessoas() {
        return lista;
    }

    public void setPessoa(Pessoa pessoa, int posicao) {
        lista[posicao] = pessoa;
    }

    public void imprimePessoasFesta() {
        for (Pessoa pessoa : lista) {
            if (pessoa != null) {
                System.out.println(pessoa.toString());
            }
        }
    }

    public boolean entraPessoa(Pessoa pessoa) {
        char sinal;
        sinal = 'n';
        for (int i = 0; i < lista.length; i++) {
            if (lista[i] == null) {
                lista[i] = pessoa;
                sinal = 's';
                break;

            }

        }
        if (sinal == 's') {
            return true;
        } else {
            return false;
        }

    }

    public Pessoa[] procuraMulheres() {
        int quantMulheres = 0;
        for (Pessoa pessoa : lista) {
            if (pessoa != null && pessoa instanceof Mulher) {
                quantMulheres++;

            }

        }

        Pessoa[] listaMulheres = new Pessoa[quantMulheres];
        int i = 0;
        for (Pessoa pessoa : lista) {
            if (pessoa != null && pessoa instanceof Mulher) {
                listaMulheres[i] = pessoa;
                i++;

            }

        }
        return listaMulheres;
    }

    public void imprimeTimeHomens() {
        for (Pessoa pessoa : lista) {
            if (pessoa != null && pessoa instanceof Homem) {
                Homem homem = (Homem) pessoa;
                System.out.println("Nome: " + homem.getNome());
                System.out.println("Time: " + homem.getTime());
                System.out.println();

            }
        }
    }

    public void achaParPerfeito() {
        for (Pessoa pessoa : lista) {
            if (pessoa instanceof Homem) {
                Homem homem = (Homem) pessoa;
                System.out.println("Mulheres que se encaixam no gostinho do : " + homem.getNome());
                for (Pessoa mulher : lista) {
                    if (mulher instanceof Mulher) {
                        Mulher par = (Mulher) mulher;
                        if (par.getCorCabelo().equals(homem.getPreferenciaCabelo())) {
                            int diferencaIdade = (homem.getIdade() - par.getIdade());
                            if (homem.getIdade() > par.getIdade()) {
                                System.out.println(par.getNome() + " tem " + par.getIdade() + " anos de idade, " + " diferença de idade é "+ diferencaIdade +  ", Ele é mais velho" );
                            } else if (homem.getIdade() < par.getIdade()) {
                                System.out.println(par.getNome() + " tem " + par.getIdade() + " anos de idade, " + " diferença de idade é "+ diferencaIdade +  ", Ela é mais velha" );
                            }else {
                                System.out.println(par.getNome() + " tem " + par.getIdade() + " anos de idade, " + " diferença de idade é "+ diferencaIdade +  ", eles tem a mesma idade" );

                            }
                          
                        }
                    }
                }
                System.out.println();
            }
        }
    }
}
